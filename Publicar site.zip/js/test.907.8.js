var visiopt_site_url = 'https://visiopt.com/client/';
				var visi_version = '202411061540';window._kx_called = false; /* Test Was paused */
	    				var _pageId = '8';
	    				if(typeof visiopt_timeout === 'undefined'){
						    var visiopt_timeout = '0';
						}
	    				var visiopt_test_id = [];
	    				var visi_winner_trck_status = 0;
	    				var visiopt_campaign_id = [];
	    				var visi_websiteId =907;
	    				if (typeof visiopt_code != 'undefined') {
	    				    visiopt_code.complete();
	    				} else {
		    				document.getElementsByTagName('HTML')[0].style.visibility = null;
		    				document.getElementsByTagName('HTML')[0].style.opacity = null;
		    			}
	    				window.visi_rot_sts=2;
		var site_id=907;var heatmap_exist=false;var scrollmap_exist=false;var recording_exist=false;